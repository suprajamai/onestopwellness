package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rays.dao.DoctorDAO;
import com.rays.dao.Doctor_Impl;
import com.rays.model.Doctor;

/**
 * Servlet implementation class UpdateDoctor
 */
@WebServlet("/UpdateDoctor")
public class UpdateDoctor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDoctor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String slot=null;		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int doctor_id=Integer.parseInt(request.getParameter("doctor_id"));
		int slotno=Integer.parseInt(request.getParameter("slot"));
		if(slotno==1)
		{
			slot=request.getParameter("slot1");
		}
		else if(slotno==2)
		{
			slot=request.getParameter("slot2");
		}
		else if(slotno==3)
		{
			slot=request.getParameter("slot3");
		}
		else if(slotno==4)
		{
			slot=request.getParameter("slot4");
		}
		DoctorDAO drd=new Doctor_Impl();
		int count=drd.updateDoctor(doctor_id,slot,slotno);
		
		if(count==1)
		{
			HttpSession hs=request.getSession();
			String hospital_name=(String)hs.getAttribute("hname");
			System.out.println(hospital_name);
			DoctorDAO dro=new Doctor_Impl();
			List<Doctor> availableList=dro.showAllAvailable(hospital_name);
			hs.setAttribute("listAvailable", availableList);
			RequestDispatcher rd=request.getRequestDispatcher("availableList.jsp");	
			pw.println("<h2 style=color:green;>Updated</h2>");
			rd.include(request, response);
			
			
		}else
		{
			RequestDispatcher rd=request.getRequestDispatcher("availableList.jsp");
			pw.println("<h2 style=color:red;>Approval Declined</h2>");
			rd.include(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

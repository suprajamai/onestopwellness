package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rays.dao.Hospital_RegistrationDAO;
import com.rays.dao.Hospital_Registration_Impl;
import com.rays.model.Hospital_Registration;

/**
* Servlet implementation class StoreHospital
*/
@WebServlet("/StoreHospital")
public class StoreHospital extends HttpServlet {
                private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StoreHospital() {
        super();
        // TODO Auto-generated constructor stub
    }

                /**
                * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
                */
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                                //response.getWriter().append("Served at: ").append(request.getContextPath());
                                
                }

                /**
                * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
                */
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                	response.setContentType("text/html"); 
                	PrintWriter pw=response.getWriter();
                              //  int hospital_id=Integer.parseInt(request.getParameter("Hospital_Id"));
                                String hospital_Name=request.getParameter("Hospital_Name");
                                String address_linea=request.getParameter("Addr_line_1");
                                String address_lineb=request.getParameter("Addr_line_2");
                                String city=request.getParameter("City");
                                String state=request.getParameter("State");
                                long pin=Long.parseLong(request.getParameter("Pin"));
                                String certifications=request.getParameter("certifications");
                                String Successful_operations=request.getParameter("Successful_operations");
                                int achievements=Integer.parseInt(request.getParameter("achievements"));
                                Hospital_Registration hr=new Hospital_Registration(hospital_Name, address_linea, address_lineb, city, state, pin, certifications,  Successful_operations, achievements);
                                Hospital_RegistrationDAO hrdao=new Hospital_Registration_Impl();
                                int status=hrdao.storeHospital(hr);   
                                if(status==1)
                                {
                                	
                                	int hospital_id=hrdao.getIdByName(hospital_Name);
                                	
                     			   pw.println("<center><h2 style=color:green;>You are successfully registered.<br>");
                                    pw.println("Your User Id is :\n"+hospital_id);
                                    pw.println("<br>Please note down your User Id for future reference\n</h2></center>");
                                                request.getRequestDispatcher("Login.jsp").include(request, response);
                                }
                                else
                                {
                                                pw.println(" Hospital Registration failed");
                                                request.getRequestDispatcher("Register_Hospital.jsp").include(request, response);
                                }
                }

}

package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rays.dao.Hospital_RegistrationDAO;
import com.rays.dao.Hospital_Registration_Impl;

/**
 * Servlet implementation class SetStatus
 */
@WebServlet("/SetStatus")
public class SetStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int hospital_id=Integer.parseInt(request.getParameter("hospitalId"));
		int status=Integer.parseInt(request.getParameter("status"));
		Hospital_RegistrationDAO hrd=new Hospital_Registration_Impl();
		int count=hrd.updateStatus(hospital_id, status);
		RequestDispatcher rd=request.getRequestDispatcher("ShowHospitalList");
		if(count==1 && status==1)
		{
			pw.println("<h2 style=color:green;>Hospital Approved</h2>");
			rd.include(request, response);
		}else
		{
			pw.println("<h2 style=color:red;>Hospital Approval Declined</h2>");
			rd.include(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

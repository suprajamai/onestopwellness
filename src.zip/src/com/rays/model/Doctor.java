package com.rays.model;

public class Doctor {
	private int doctor_id;
private String doctor_name;
private String specialization;
private String hospital_Name;
private String slot1;
private String slot2;
private String slot3;
private String slot4;
public int getDoctor_id() {
	return doctor_id;
}
public void setDoctor_id(int doctor_id) {
	this.doctor_id = doctor_id;
}
public String getDoctor_name() {
	return doctor_name;
}
public void setDoctor_name(String doctor_name) {
	this.doctor_name = doctor_name;
}
public String getSpecialization() {
	return specialization;
}
public void setSpecialization(String specialization) {
	this.specialization = specialization;
}

public String getHospital_Name() {
	return hospital_Name;
}
public void setHospital_Name(String hospital_Name) {
	this.hospital_Name = hospital_Name;
}
public String getSlot1() {
	return slot1;
}
public void setSlot1(String slot1) {
	this.slot1 = slot1;
}
public String getSlot2() {
	return slot2;
}
public void setSlot2(String slot2) {
	this.slot2 = slot2;
}
public String getSlot3() {
	return slot3;
}
public void setSlot3(String slot3) {
	this.slot3 = slot3;
}
public String getSlot4() {
	return slot4;
}
public void setSlot4(String slot4) {
	this.slot4 = slot4;
}
public Doctor() {
	super();
	// TODO Auto-generated constructor stub
}
public Doctor(int doctor_id, String doctor_name, String specialization, String hospital_Name) {
	super();
	this.doctor_id = doctor_id;
	this.doctor_name = doctor_name;
	this.specialization = specialization;
	this.hospital_Name = hospital_Name;
}

}

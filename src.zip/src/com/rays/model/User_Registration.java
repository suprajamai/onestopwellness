package com.rays.model;

public class User_Registration {
	
		private int User_Id;
		private String First_Name;
		private String Last_Name;
		private int Age;
		private String Gender;
		private long Contact_Number;
		private String Address;
		private String City;
		private long Zip_code;
		private String Password;

		public String getPassword() {
			return Password;
		}
		public void setPassword(String password) {
			Password = password;
		}
		public int getUser_Id() {
		       return User_Id;
		}
		public void setUser_Id(int user_Id) {
		       User_Id = user_Id;
		}
		public String getFirst_Name() {
		       return First_Name;
		}
		public void setFirst_Name(String first_Name) {
		       First_Name = first_Name;
		}
		public String getLast_Name() {
		       return Last_Name;
		}
		public void setLast_Name(String last_Name) {
		       Last_Name = last_Name;
		}
		public int getAge() {
		       return Age;
		}
		public void setAge(int age) {
		       Age = age;
		}
		public String getGender() {
		       return Gender;
		}
		public void setGender(String gender) {
		       Gender = gender;
		}
		public long getContact_Number() {
		       return Contact_Number;
		}
		public void setContact_Number(long contact_Number) {
		       Contact_Number = contact_Number;
		}
		public String getAddress() {
		       return Address;
		}
		public void setAddress(String address) {
		       Address = address;
		}
		public String getCity() {
		       return City;
		}
		public void setCity(String city) {
		       City = city;
		}
		public long getZip_code() {
		       return Zip_code;
		}
		public void setZip_code(long zip_code) {
		       Zip_code = zip_code;
		}
		public User_Registration() {
		       super();
		       // TODO Auto-generated constructor stub
		}
		public User_Registration(String first_Name, String last_Name, int age, String gender, long contact_Number,
				String address, String city, long zip_code, String password) {
			super();
			First_Name = first_Name;
			Last_Name = last_Name;
			Age = age;
			Gender = gender;
			Contact_Number = contact_Number;
			Address = address;
			City = city;
			Zip_code = zip_code;
			Password = password;
		}
		
}

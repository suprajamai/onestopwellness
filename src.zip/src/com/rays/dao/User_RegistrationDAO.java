package com.rays.dao;
import com.rays.model.User_Registration;
public interface User_RegistrationDAO {
	public int insertUser(User_Registration ur);
	public int validateUser(String User_id,String Password);	
	public int getUserId(long contact);
}

package com.rays.dao;

import java.util.List;

import com.rays.model.Hospital_Registration;

public interface Hospital_RegistrationDAO {
       
       public int storeHospital(Hospital_Registration hr);
       public List<Hospital_Registration> showAllHospital();
       public int updateStatus(int hopital_id,int status);
       public int validateHospital(String hospital_id);
       public int getIdByName(String hname);
}

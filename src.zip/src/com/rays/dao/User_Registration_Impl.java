package com.rays.dao;

import com.rays.model.Hospital_Registration;
import com.rays.model.User_Registration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.rays.connection.ConnectionFactory;
public class User_Registration_Impl implements User_RegistrationDAO {
                  Connection con=null;
      public User_Registration_Impl() {
             // TODO Auto-generated constructor stub
             this.con=ConnectionFactory.openConn();
      }

                @Override
                public int insertUser(User_Registration ur) {
                                int status=0;
                                try {
                                	ResultSet rs;
                                                PreparedStatement ps=con.prepareStatement("insert into user_reg_details(First_Name, Last_Name,Age,Gender,Contact_Number,Address,City,Zip_code,Password) values(?,?,?,?,?,?,?,?,?)");
                                                //ps.setInt(1, ur.getUser_Id());
                                                ps.setString(1, ur.getFirst_Name());
                                                ps.setString(2, ur.getLast_Name());
                                                ps.setInt(3, ur.getAge());
                                                ps.setString(4, ur.getGender());
                                                ps.setLong(5, ur.getContact_Number());
                                                ps.setString(6, ur.getAddress());
                                                ps.setString(7, ur.getCity());
                                                ps.setLong(8, ur.getZip_code());
                                                ps.setString(9, ur.getPassword());
                                                status=ps.executeUpdate();
                                               /* rs = ps.getGeneratedKeys();
                                                while (rs.next()) {
                                                	 int id = rs.getInt(10);
                                                	 System.out.println("Your User Id is "+id);
                                                }*/
                                                /*Statement st=con.createStatement();
                                                rs=st.executeQuery("select User_Id from user_reg_details");
                                             
                            					ur.setUser_Id(rs.getInt(1));*/
                                }catch (Exception e) {
                                		if(e.getMessage().startsWith("Duplicate entry"))
                                			status=2;
                                                System.out.println("Error in Insert User "+e);
                                }
                              
                                return status;
                }

				@Override
				public int validateUser(String User_id, String Password) {
					int status=0;
					try {
						  						
						 PreparedStatement ps = con.prepareStatement("Select User_id, Password from user_reg_details where User_id=? and Password=?");
						 ps.setString(1,User_id);
						
							ps.setString(2,Password);
							// TODO Auto-generated catch block
						
								 java.sql.ResultSet rs = ps.executeQuery();
						 if(rs.next())
						 {
							status=1;
						 }
						 else
						 {
							 status=0;
						 }
						 
					}
						catch(Exception e)
						{
							System.out.println("Error in Validate User :"+e);
						}
					return status;
				}

				@Override
				public int getUserId(long contact) {
					int user_id=0;
					try {
						  						
						 PreparedStatement ps = con.prepareStatement("Select User_id from user_reg_details where Contact_Number=?");
						 ps.setLong(1,contact);
						 ResultSet rs = ps.executeQuery();
						 if(rs.next())
						 {
							user_id=rs.getInt(1);
						 }
						 else
						 {
							 user_id=0;
						 }
						 
					}
						catch(Exception e)
						{
							System.out.println("Error in Validate User :"+e);
						}
					return user_id;
				}
}




package com.rays.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

import com.rays.connection.ConnectionFactory;
import com.rays.model.Doctor;

public class Doctor_Impl implements DoctorDAO {
	 Connection con=null;
     public Doctor_Impl() {
            // TODO Auto-generated constructor stub
            this.con=ConnectionFactory.openConn();
     }
	@Override
	public int insertDoctor(Doctor dr) {
		int count=0;
        try {

                        PreparedStatement ps=con.prepareStatement("insert into doctor (doctor_id,doctor_name,specialization,Hospital_Name)values(?,?,?,?)");
                        ps.setInt(1, dr.getDoctor_id());
                        ps.setString(2, dr.getDoctor_name());
                        ps.setString(3, dr.getSpecialization());
                        ps.setString(4, dr.getHospital_Name());
                        count=ps.executeUpdate();
        }catch (Exception e) {
                        System.out.println("Error in Insert doctor "+e);
        }
        return count;
	}
	@Override
	public int updateDoctor(int doctor_id,String slot,int slotno) {
		int count=0;
		 try {
			 
             PreparedStatement ps=con.prepareStatement("update doctor set slot?=? where doctor_id=?");
             ps.setInt(1, slotno);
             ps.setString(2, slot);
             ps.setInt(3, doctor_id); 
             count=ps.executeUpdate();
      }catch (Exception e) {
             System.out.println("Error in Updating hospital status"+e);
             count=0;
      }
      return count;
	}
	@Override
	public List<Doctor> showAllAvailable(String hospital_name) {
		List<Doctor> availableList=new ArrayList<Doctor>();
		try {
			PreparedStatement st=con.prepareStatement("select * from doctor where hospital_name=?");
			st.setString(1, hospital_name);
			ResultSet rs=st.executeQuery();
			
			while(rs.next())
			{
				Doctor dr=new Doctor();
				dr.setDoctor_id(rs.getInt(1));
				dr.setDoctor_name(rs.getString(2));
				dr.setSpecialization(rs.getString(3));
				dr.setHospital_Name(rs.getString(4));
				dr.setSlot1(rs.getString(5));
				dr.setSlot2(rs.getString(6));
				dr.setSlot3(rs.getString(7));
				dr.setSlot4(rs.getString(8));
				availableList.add(dr);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	
	return availableList;
	}
	
	public String getHospitalNameById(String hospital_id)
	{
		String hospital_name=null;
		try {
			PreparedStatement st=con.prepareStatement("select Hospital_Name from hospital_register where Hospital_id=?");
			st.setString(1, hospital_id);
			ResultSet rs=st.executeQuery();
			
			if(rs.next())
			{
				hospital_name=rs.getString(1);
			}			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return hospital_name;
	}

}

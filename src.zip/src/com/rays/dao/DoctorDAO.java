package com.rays.dao;

import java.util.List;

import com.rays.model.Doctor;

public interface DoctorDAO {
	public int insertDoctor(Doctor dr);
	public List<Doctor> showAllAvailable(String hospital_name);
	public int updateDoctor(int doctor_id, String slot,int slotno);
	public String getHospitalNameById(String hospital_id);
	}
